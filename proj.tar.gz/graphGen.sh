#!/bin/bash

# Change the input graph as desired

./input_graphs/SNAPtoBinary input_graphs/testGraph.txt input_graphs/graph
